BOT GRASS SESSION 2 LIVE NOW !!
NEW USER TO JOIN : https://app.getgrass.io/register?referralCode=14euVrmXslgPwPI

need userid : check this video to get userid

format proxy ( proxy.txt )
http://user:pass@ip:port 

u can change http or socks5 or socks4 dll 
